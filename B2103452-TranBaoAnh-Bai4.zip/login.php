<!DOCTYPE HTML>
<html>  
<body>

<form action="log.php" method="post">
Username: <input type="text" name="email"><br>
Password: <input type="password" name="pass"><br>

<input type="submit">
</form>

</body>
</html>
