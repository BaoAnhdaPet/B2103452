<!DOCTYPE HTML>
<html>  
<body>

<form action="luu.php" method="post">
Major Name: <input type="text" name="name"><br>
<input type="submit">
</form>

</body>
</html>